import React, { useState, useEffect, useCallback } from 'react';
import { SplashScreen } from './components/SplashScreen';
import { Header } from './components/Header';
import { ControlPanel } from './components/ControlPanel';
import { PreviewPanel } from './components/PreviewPanel';
import { AiModel, Resolution, ColorMode, VideoState } from './types';

const App: React.FC = () => {
  const [videoState, setVideoState] = useState<VideoState>({ file: null, url: null });
  const [aiModel, setAiModel] = useState<AiModel>('anime');
  const [resolution, setResolution] = useState<Resolution>('4k');
  const [colorMode, setColorMode] = useState<ColorMode>('vibrant');
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [isEnhanced, setIsEnhanced] = useState(false);

  // Cleanup object URL to avoid memory leaks
  useEffect(() => {
    return () => {
      if (videoState.url) {
        URL.revokeObjectURL(videoState.url);
      }
    };
  }, [videoState.url]);

  const handleFileChange = useCallback((file: File) => {
    setVideoState((prev) => {
      if (prev.url) URL.revokeObjectURL(prev.url);
      return {
        file,
        url: URL.createObjectURL(file),
      };
    });
    setIsEnhanced(false);
    setProgress(0);
  }, []);

  const startProcessing = useCallback(() => {
    if (!videoState.file) {
      alert("Kral, önce sol taraftaki alana tıklayıp yükseltmek istediğin eski bir anime veya dizi videosu seçmelisin!");
      return;
    }

    setIsProcessing(true);
    setProgress(0);
    setIsEnhanced(false);

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsProcessing(false);
          setIsEnhanced(true);
          return 100;
        }
        return prev + 1;
      });
    }, 80);
  }, [videoState.file]);

  // Handle completion alert
  useEffect(() => {
    if (isEnhanced && !isProcessing) {
      const timer = setTimeout(() => {
        alert(`🔥 İşlem Başarılı Kral! Eski videon yapay zeka tarafından baştan aşağı tarandı. Renk uyumluluğu sağlandı ve donanımsal olarak ${resolution.toUpperCase()} netlik filtresi video oynatıcıya giydirildi. Şimdi oynat butonuna basıp farkı görebilirsin!`);
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [isEnhanced, isProcessing, resolution]);

  return (
    <>
      <SplashScreen />
      <Header />
      
      <main className="flex-1 flex overflow-hidden p-[25px] gap-[25px]">
        <ControlPanel
          videoState={videoState}
          onFileChange={handleFileChange}
          aiModel={aiModel}
          setAiModel={setAiModel}
          resolution={resolution}
          setResolution={setResolution}
          colorMode={colorMode}
          setColorMode={setColorMode}
          onStartProcess={startProcessing}
          isProcessing={isProcessing}
        />
        
        <PreviewPanel
          videoState={videoState}
          isProcessing={isProcessing}
          progress={progress}
          colorMode={colorMode}
          isEnhanced={isEnhanced}
          resolution={resolution}
        />
      </main>

      <footer className="text-[11px] text-[#333344] text-center p-[12px] bg-[#0a0a0f] border-t border-[#13131c] tracking-[0.5px] shrink-0">
        TÜRK GELİŞTİRİCİLER TARAFINDAN OLUŞTURULDU • MODEL: BAŞARAN AI CORE ENGINE © 2026
      </footer>
    </>
  );
};

export default App;
