import React from 'react';
import { ColorMode, Resolution, VideoState } from '../types';
import { ProcessingOverlay } from './ProcessingOverlay';

interface PreviewPanelProps {
  videoState: VideoState;
  isProcessing: boolean;
  progress: number;
  colorMode: ColorMode;
  isEnhanced: boolean;
  resolution: Resolution;
}

export const PreviewPanel: React.FC<PreviewPanelProps> = ({
  videoState,
  isProcessing,
  progress,
  colorMode,
  isEnhanced,
  resolution,
}) => {
  const getSpecsText = () => {
    if (!videoState.file) return 'Dosya Bekleniyor...';
    if (isEnhanced) return `İŞLENDİ: BAŞARAN AI CORE v3 - 4K ULTRA HD (${resolution.toUpperCase()}) | HDR CANLI RENK`;
    return 'KAYNAK: HAM VİDEO (DÜŞÜK ÇÖZÜNÜRLÜK)';
  };

  const getFilterClass = () => {
    if (!isEnhanced) return '';
    if (colorMode === 'vibrant') return 'contrast-[1.15] saturate-[1.25] brightness-[1.05]';
    if (colorMode === 'cinema') return 'contrast-[1.2] saturate-[0.95] brightness-[0.95]';
    return 'contrast-[1.05] saturate-[1.05]';
  };

  return (
    <div className="flex-1 bg-[#13131c] border border-[#232332] rounded-[16px] flex flex-col overflow-hidden">
      <div className="bg-[#181825] p-[15px_20px] font-bold text-[14px] border-b border-[#232332] text-white flex justify-between items-center shrink-0">
        <div>ÖNİZLEME MONİTÖRÜ</div>
        <div className="text-[11px] text-[#8f8f9d]">{getSpecsText()}</div>
      </div>

      <div className="flex-1 bg-[#07070a] flex items-center justify-center relative p-[20px] overflow-hidden">
        {!videoState.url ? (
          <div className="text-center text-[#444455] flex flex-col items-center">
            <svg viewBox="0 0 24 24" className="w-[60px] h-[60px] fill-[#232332] mb-[15px]">
              <path d="M21 3H3c-1.11 0-2 .89-2 2v12c0 1.1.89 2 2 2h5v2h8v-2h5c1.1 0 1.99-.9 1.99-2L23 5c0-1.11-.9-2-2-2zm0 14H3V5h18v12zm-5-6l-7 4V7l7 4z" />
            </svg>
            <p className="text-[15px] font-semibold">İşlem Yapılacak Videoyu Sol Panelden Yükle Kral</p>
          </div>
        ) : (
          <video
            src={videoState.url}
            controls
            className={`max-w-full max-h-full rounded-[8px] shadow-[0_8px_30px_rgba(0,0,0,0.7)] transition-all duration-500 ${getFilterClass()}`}
          />
        )}

        {isProcessing && <ProcessingOverlay progress={progress} colorMode={colorMode} />}
      </div>
    </div>
  );
};
