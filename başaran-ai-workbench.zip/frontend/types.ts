export type AiModel = 'anime' | 'cinema' | 'fast';
export type Resolution = '4k' | '2k' | '1080p';
export type ColorMode = 'vibrant' | 'cinema' | 'original';

export interface VideoState {
  file: File | null;
  url: string | null;
}
