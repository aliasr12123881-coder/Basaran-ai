import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="bg-[#13131c] py-[15px] px-[25px] flex items-center justify-between border-b border-[#232332] shadow-[0_4px_20px_rgba(0,0,0,0.5)] shrink-0">
      <div className="flex items-center gap-[12px]">
        <span className="text-[22px]">🇹🇷</span>
        <div className="text-[22px] font-extrabold text-white">
          BAŞARAN{' '}
          <span className="bg-gradient-to-r from-[#00ffcc] to-[#0077ff] text-transparent bg-clip-text">
            AI LAB v3
          </span>
        </div>
      </div>
      <div className="bg-[#1a3a3a] text-[#00ffcc] text-[11px] font-extrabold py-[4px] px-[10px] rounded-[20px] border border-[#00aa88]">
        AI SINIRSIZ MODU AKTİF
      </div>
    </header>
  );
};
