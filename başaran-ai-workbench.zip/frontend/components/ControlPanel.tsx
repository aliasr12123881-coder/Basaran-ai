import React, { useRef } from 'react';
import { AiModel, Resolution, ColorMode, VideoState } from '../types';

interface ControlPanelProps {
  videoState: VideoState;
  onFileChange: (file: File) => void;
  aiModel: AiModel;
  setAiModel: (model: AiModel) => void;
  resolution: Resolution;
  setResolution: (res: Resolution) => void;
  colorMode: ColorMode;
  setColorMode: (mode: ColorMode) => void;
  onStartProcess: () => void;
  isProcessing: boolean;
}

export const ControlPanel: React.FC<ControlPanelProps> = ({
  videoState,
  onFileChange,
  aiModel,
  setAiModel,
  resolution,
  setResolution,
  colorMode,
  setColorMode,
  onStartProcess,
  isProcessing,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDropZoneClick = () => {
    if (!isProcessing && fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onFileChange(file);
    }
  };

  const formatFileSize = (bytes: number) => {
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  return (
    <div className="w-[380px] bg-[#13131c] border border-[#232332] rounded-[16px] p-[20px] flex flex-col gap-[20px] overflow-y-auto shrink-0">
      <div className="text-[16px] font-bold text-white border-b border-[#232332] pb-[10px]">
        Video Optimizasyon Kontrolleri
      </div>

      {/* Drop Zone */}
      <div
        onClick={handleDropZoneClick}
        className={`border-2 border-dashed border-[#333344] bg-[#171724] rounded-[12px] p-[30px_20px] text-center transition-colors duration-200 relative flex flex-col items-center justify-center ${
          isProcessing ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:border-[#00ffcc] hover:bg-[#1a242a]'
        }`}
      >
        <svg viewBox="0 0 24 24" className="w-[40px] h-[40px] fill-[#00ffcc] mb-[10px]">
          <path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM14 13v4h-4v-4H7l5-5 5 5h-3z" />
        </svg>
        <p className="text-[14px] text-[#a0a0b0] font-medium">
          {videoState.file ? 'Dosya Başarıyla Bağlandı!' : 'Anime, Dizi veya Video Seç'}
        </p>
        <span className="text-[11px] text-[#555566] block mt-[5px]">
          {videoState.file
            ? `${videoState.file.name} (${formatFileSize(videoState.file.size)})`
            : 'MP4, MKV, AVI, MOV desteklenir'}
        </span>
      </div>
      <input
        type="file"
        ref={fileInputRef}
        className="hidden"
        accept="video/*"
        onChange={handleFileSelect}
        disabled={isProcessing}
      />

      {/* Options */}
      <div className="flex flex-col gap-[8px]">
        <label className="text-[13px] font-semibold text-[#8f8f9d] uppercase tracking-[0.5px]">
          Yapay Zeka Çizim & Ölçekleme Motoru
        </label>
        <select
          value={aiModel}
          onChange={(e) => setAiModel(e.target.value as AiModel)}
          disabled={isProcessing}
          className="bg-[#171724] border border-[#232332] text-white p-[12px] rounded-[10px] outline-none text-[14px] w-full cursor-pointer focus:border-[#00ffcc] disabled:opacity-50"
        >
          <option value="anime">Başaran Anime-Enhance Engine (Çizgileri Düzeltir)</option>
          <option value="cinema">Başaran Cinema-Cubic v2 (Eski Dizileri 4K Yapar)</option>
          <option value="fast">Hyper-Upscale Express (Hızlı Çözünürlük Artırıcı)</option>
        </select>
      </div>

      <div className="flex flex-col gap-[8px]">
        <label className="text-[13px] font-semibold text-[#8f8f9d] uppercase tracking-[0.5px]">
          Hedef Çözünürlük Standartı
        </label>
        <select
          value={resolution}
          onChange={(e) => setResolution(e.target.value as Resolution)}
          disabled={isProcessing}
          className="bg-[#171724] border border-[#232332] text-white p-[12px] rounded-[10px] outline-none text-[14px] w-full cursor-pointer focus:border-[#00ffcc] disabled:opacity-50"
        >
          <option value="4k">4K Ultra HD (3840 x 2160) - Tavsiye Edilen</option>
          <option value="2k">2K Quad HD (2560 x 1440)</option>
          <option value="1080p">Full HD (1920 x 1080) - Keskin Renk Modu</option>
        </select>
      </div>

      <div className="flex flex-col gap-[8px]">
        <label className="text-[13px] font-semibold text-[#8f8f9d] uppercase tracking-[0.5px]">
          AI Renk ve HDR Optimizasyonu
        </label>
        <select
          value={colorMode}
          onChange={(e) => setColorMode(e.target.value as ColorMode)}
          disabled={isProcessing}
          className="bg-[#171724] border border-[#232332] text-white p-[12px] rounded-[10px] outline-none text-[14px] w-full cursor-pointer focus:border-[#00ffcc] disabled:opacity-50"
        >
          <option value="vibrant">Canlı & Uyumlu Renkler (Anime Tonlaması)</option>
          <option value="cinema">Sinematik Soluk & Derin Kontrast (Dizi Tonu)</option>
          <option value="original">Orijinal Spektrumu Koru (Sadece Parlaklık)</option>
        </select>
      </div>

      <button
        onClick={onStartProcess}
        disabled={isProcessing}
        className={`bg-gradient-to-br from-[#00ffcc] to-[#0055ff] text-black border-none p-[15px] rounded-[12px] text-[15px] font-bold transition-all duration-200 text-center shadow-[0_4px_15px_rgba(0,255,204,0.2)] mt-[10px] ${
          isProcessing ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:-translate-y-[2px] hover:shadow-[0_6px_20px_rgba(0,255,204,0.4)]'
        }`}
      >
        {isProcessing ? 'İşleniyor...' : 'Yapay Zeka Kalitesini Yükselt'}
      </button>
    </div>
  );
};
