import React, { useEffect, useState } from 'react';

export const SplashScreen: React.FC = () => {
  const [isVisible, setIsVisible] = useState(true);
  const [isFading, setIsFading] = useState(false);

  useEffect(() => {
    const fadeTimer = setTimeout(() => setIsFading(true), 1500);
    const removeTimer = setTimeout(() => setIsVisible(false), 1900);

    return () => {
      clearTimeout(fadeTimer);
      clearTimeout(removeTimer);
    };
  }, []);

  if (!isVisible) return null;

  return (
    <div
      className={`fixed inset-0 w-full h-full bg-[#0f0f15] flex flex-col items-center justify-center z-[9999] transition-opacity duration-400 ease-in-out ${
        isFading ? 'opacity-0' : 'opacity-100'
      }`}
    >
      <div className="text-[55px] mb-[15px] animate-pulse">🇹🇷</div>
      <div className="text-[34px] font-black text-white tracking-[1px]">
        BAŞARAN{' '}
        <span className="bg-gradient-to-r from-[#00ffcc] to-[#0077ff] text-transparent bg-clip-text">
          AI WORKBENCH
        </span>
      </div>
    </div>
  );
};
