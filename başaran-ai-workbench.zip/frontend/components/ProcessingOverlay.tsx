import React from 'react';
import { ColorMode } from '../types';

interface ProcessingOverlayProps {
  progress: number;
  colorMode: ColorMode;
}

export const ProcessingOverlay: React.FC<ProcessingOverlayProps> = ({ progress, colorMode }) => {
  let title = '';
  let sub = '';

  if (progress < 25) {
    title = '🔍 Pikseller Ayrıştırılıyor...';
    sub = 'Eski videodaki bozuk alanlar, bulanık kareler ve gürültüler yapay zeka tarafından taranıyor.';
  } else if (progress >= 25 && progress < 55) {
    title = '⚡ 4K Çözünürlük Çizgileri Ekleniyor...';
    sub = 'Çizgiler keskinleştiriliyor. Boş kalan pikseller arasına yapay zeka yeni pikseller çizerek görüntüyü 4K standartına katlıyor.';
  } else if (progress >= 55 && progress < 85) {
    title = '🎨 Renk Spektrumu ve HDR Optimizasyonu...';
    sub = `Seçtiğin '${colorMode === 'vibrant' ? 'Canlı Renkler' : 'Sinematik Derinlik'}' modu uygulanıyor. Soluk renkler canlandırılıyor.`;
  } else {
    title = '🚀 Kare Hızı Senkronizasyonu (60 FPS)...';
    sub = 'Video akıcılığı optimize ediliyor, son kontroller gerçekleştiriliyor kral.';
  }

  return (
    <div className="absolute inset-0 w-full h-full bg-black/95 flex flex-col items-center justify-center p-[40px] z-10">
      <div className="w-[50px] h-[50px] border-4 border-[#00ffcc]/10 border-t-[#00ffcc] rounded-full animate-spin mb-[20px]"></div>
      <div className="text-[18px] font-bold text-white mb-[8px]">{title}</div>
      <div className="text-[13px] text-[#8f8f9d] mb-[20px] text-center max-w-[400px]">{sub}</div>

      <div className="w-full max-w-[400px] h-[6px] bg-[#222232] rounded-[3px] overflow-hidden mb-[10px]">
        <div
          className="h-full bg-gradient-to-r from-[#00ffcc] to-[#0077ff] transition-all duration-100 ease-linear"
          className={`h-full bg-gradient-to-r from-[#00ffcc] to-[#0077ff] transition-all duration-100 ease-linear w-[${progress}%]`}
        ></div>
      </div>
      <div className="text-[14px] font-bold text-[#00ffcc]">{progress}%</div>
    </div>
  );
};
